On an air-gapped device, open 

  offline/index.html 

(testing was performed on the Firefox and Chrome browsers).

Use the wallets to manage keys and sign transactions.

A connected device such as a phone can be used to retrieve the parameters 
(such as wallet nonce and gas price) needed to prepare transactions.

Once signed, transactions can be saved to text files, moved back to the 
online device, and safely broadcast to the Ethereum network.

